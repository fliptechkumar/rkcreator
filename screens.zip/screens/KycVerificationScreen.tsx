import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { API_ENDPOINTS } from '../config/env';

type Props = NativeStackScreenProps<RootStackParamList, 'KycVerification'>;

export default function KycVerificationScreen({ navigation, route }: Props) {
  const [taxNumber, setTaxNumber] = useState('');
  const [aadhaarNumber, setAadhaarNumber] = useState('');
  const [gstin, setGstin] = useState('');
   const [attachment, setAttachment] = useState(null)
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const customerId = route.params?.customerId;
  const isDisabled = useMemo(
    () =>
      loading ||
      !taxNumber.trim() ||
      aadhaarNumber.trim().length !== 12 ||
      !gstin.trim() ||
      !customerId,
    [loading, taxNumber, aadhaarNumber, gstin, customerId],
  );

  const pickAttachment = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.pdf],
      });

      if (result && result.length > 0) {
        setAttachment(result[0]);
      }
    } catch (error: any) {
      if (!DocumentPicker.isCancel(error)) {
        setErrorMessage(error?.message || 'Failed to pick attachment');
      }
    }
   };

  const handleSubmitKyc = async () => {
    if (!customerId) {
      setErrorMessage('Customer id not found. Please register again.');
      return;
    }

    if (!taxNumber.trim()) {
      setErrorMessage('Tax number is required');
      return;
    }

    if (aadhaarNumber.trim().length !== 12) {
      setErrorMessage('Enter valid 12-digit Aadhaar number');
      return;
    }

    if (!gstin.trim()) {
      setErrorMessage('GSTIN is required');
      return;
    }

    // if (!attachment) {
    //   setErrorMessage('Attachment is required');
    //   return;
    // }

    setLoading(true);
    setErrorMessage('');

    try {
      const formData = new FormData();
      formData.append('id', customerId);
      formData.append('tax_number', taxNumber.trim());
      formData.append('aadhar_number', aadhaarNumber.trim());
      formData.append('adhar_number', aadhaarNumber.trim());
      formData.append('gstin', gstin.trim());
      formData.append('attachment_1', {
        uri: attachment.uri,
        name: attachment.name || `kyc_${Date.now()}`,
        type: attachment.type || 'application/octet-stream',
      } as any);

      const response = await fetch(API_ENDPOINTS.KYC_VERIFICATION, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          Internal: 'Nezlan',
        },
        body: formData,
      });

      const responseData = await response.json();

      if (responseData?.success) {
        setLoading(false);
        alert(responseData?.message || 'KYC submitted successfully.');
        navigation.replace('Login');
        return;
      }

      setLoading(false);
      setErrorMessage(responseData?.message || 'Failed to submit KYC');
    } catch (error: any) {
      setLoading(false);
      setErrorMessage(error?.message || 'Failed to submit KYC');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="dark-content" backgroundColor="#2BC0AC" />

      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Verify KYC</Text>
        <View style={styles.headerRight} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <Text style={styles.subtitle}>Complete KYC to continue with your account.</Text>

          <Text style={styles.label}>Tax Number</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Enter tax number"
            placeholderTextColor="#999"
            value={taxNumber}
            onChangeText={setTaxNumber}
            editable={!loading}
          />

          <Text style={styles.label}>Aadhaar Number</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Enter 12-digit Aadhaar number"
            placeholderTextColor="#999"
            value={aadhaarNumber}
            onChangeText={(text) => setAadhaarNumber(text.replace(/[^0-9]/g, ''))}
            keyboardType="number-pad"
            maxLength={12}
            editable={!loading}
          />

          <Text style={styles.label}>GSTIN</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Enter GSTIN"
            placeholderTextColor="#999"
            value={gstin}
            onChangeText={setGstin}
            autoCapitalize="characters"
            editable={!loading}
          />

          <Text style={styles.label}>Attachment</Text>
          <TouchableOpacity style={styles.attachmentButton} onPress={pickAttachment} disabled={loading}>
            <Ionicons name="attach" size={18} color="#2BC0AC" />
            <Text style={styles.attachmentText} numberOfLines={1}>
              {'Upload Aadhaar/PAN/GST document'}
            </Text>
          </TouchableOpacity>

          {errorMessage ? (
            <View style={styles.errorContainer}>
              <Ionicons name="alert-circle" size={18} color="#E94560" />
              <Text style={styles.errorText}>{errorMessage}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.primaryButton, isDisabled && styles.buttonDisabled]}
            onPress={handleSubmitKyc}
            disabled={isDisabled}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={styles.primaryButtonText}>Submit KYC</Text>
                <Ionicons name="checkmark-circle" size={20} color="#fff" />
              </>
            )}
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: '#2BC0AC',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  backButton: {
    width: 40,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  headerRight: {
    width: 40,
  },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 24,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 18,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  textInput: {
    fontSize: 16,
    color: '#333',
    backgroundColor: '#F8F8F8',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 14,
  },
  attachmentButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F8F8',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 14,
    gap: 8,
  },
  attachmentText: {
    color: '#333',
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
    marginBottom: 14,
  },
  errorText: {
    fontSize: 13,
    color: '#E94560',
    flex: 1,
  },
  primaryButton: {
    backgroundColor: '#2BC0AC',
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 6,
  },
  buttonDisabled: {
    backgroundColor: '#B0B0B0',
  },
  primaryButtonText: {
    fontSize: 17,
    fontWeight: '600',
    color: '#fff',
  },
});
